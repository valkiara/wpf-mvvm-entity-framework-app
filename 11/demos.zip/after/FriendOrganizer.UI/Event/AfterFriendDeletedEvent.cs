﻿using Prism.Events;

namespace FriendOrganizer.UI.Event
{
  public class AfterFriendDeletedEvent : PubSubEvent<int>
  {
  }
}
