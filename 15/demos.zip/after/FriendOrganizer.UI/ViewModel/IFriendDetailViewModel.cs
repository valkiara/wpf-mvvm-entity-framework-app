﻿namespace FriendOrganizer.UI.ViewModel
{
  public interface IFriendDetailViewModel : IDetailViewModel
  {
  }
}