This module starts where the previous module has ended. 

That means you find the starter demo for this module in the previous module's "after"-folder.