﻿namespace FriendOrganizer.UI.ViewModel
{
  public interface IMeetingDetailViewModel : IDetailViewModel
  {
  }
}
