﻿using Prism.Events;

namespace FriendOrganizer.UI.Event
{
  public class OpenFriendDetailViewEvent:PubSubEvent<int?>
  {
  }
}
